import java.util.ArrayList;
import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {

        Scanner scanner = new Scanner(System.in);
        ArrayList<Aeropuerto> aeropuertos = new ArrayList<>();

        while (true) {
            System.out.println("\n1.>>> Registrar Aeropuerto <<<");
            System.out.println("2. >>> Reservar asientos en vuelo <<<");
            System.out.println("3. >>> Registrar vuelo que parte del aeropuerto <<<");
            System.out.println("4. >>> Registrar vuelo que llega al aeropuerto <<<");
            System.out.println("5. >>> Ver cantidad de pasajeros en un vuelo <<<");
            System.out.println("6. >>> Salir <<< ");
            System.out.print("Seleccione una opcion: ");

            int opcion = scanner.nextInt();
            scanner.nextLine(); 

            switch (opcion) {
                case 1:
                    registrarAeropuerto(aeropuertos, scanner);
                    break;
                case 2:
                    reservarAsientosEnVuelo(aeropuertos, scanner);
                    break;
                case 3:
                    registrarVueloPartida(aeropuertos, scanner);
                    break;
                case 4:
                    registrarVueloLlegada(aeropuertos, scanner);
                    break;
                case 5:
                    verCantidadPasajerosEnVuelo(aeropuertos, scanner);
                    break;
                case 6:
                    break;
                default:
                    System.out.println("Opcion no invalida");
            }
        }
    }

    private static void registrarAeropuerto(ArrayList<Aeropuerto> aeropuertos, Scanner scanner) {
        System.out.print("Ingrese el nombre del aeropuerto: ");
        String nombre = scanner.nextLine();
        System.out.print("Ingrese la ubicacion del aeropuerto: ");
        String ubicacion = scanner.nextLine();

        Aeropuerto nuevoAeropuerto = new Aeropuerto(nombre, ubicacion);
        aeropuertos.add(nuevoAeropuerto);

        System.out.println("Aeropuerto registrado exitosamente.");
    }

    private static void reservarAsientosEnVuelo(ArrayList<Aeropuerto> aeropuertos, Scanner scanner) {
        System.out.print("Ingrese el numero de vuelo: ");
        int numeroVuelo = scanner.nextInt();
        scanner.nextLine(); 

        Vuelo vuelo = buscarVueloPorNumero(aeropuertos, numeroVuelo);
        if (vuelo != null) {
            System.out.print("Ingrese el numero de asientos que desea reservar: ");
            int numeroAsientos = scanner.nextInt();
            scanner.nextLine(); 

            if (vuelo.reservarAsiento(numeroAsientos)) {
                System.out.println("Asientos reservados con exitosamente.");
            } else {
                System.out.println("No se pudieron reservar los asientos. Verifique la disponibilidad.");
            }
        } else {
            System.out.println("No se encontro el vuelo con el numero especificado.");
        }
    }

    private static void registrarVueloPartida(ArrayList<Aeropuerto> aeropuertos, Scanner scanner) {
        System.out.print("Ingrese el numero de vuelo: ");
        int numeroVuelo = scanner.nextInt();
        scanner.nextLine(); 

        if (!existeNumeroVuelo(aeropuertos, numeroVuelo)) {
            System.out.print("Ingrese el nombre de la aerolinea: ");
            String aerolinea = scanner.nextLine();
            System.out.print("Ingrese la hora de salida: ");
            String horaSalida = scanner.nextLine();
            System.out.print("Ingrese  el destino donde desea viajar: ");
            String destino = scanner.nextLine();
            System.out.print("Ingrese la capacidad maxima: ");
            int capacidadMaxima = scanner.nextInt();
            scanner.nextLine(); 

            System.out.print("Ingrese el nombre del aeropuerto de partida: ");
            String nombreAeropuertoPartida = scanner.nextLine();
            Aeropuerto aeropuertoPartida = buscarAeropuertoPorNombre(aeropuertos, nombreAeropuertoPartida);

            if (aeropuertoPartida != null) {
                Vuelo vuelo = new Vuelo(numeroVuelo, aerolinea, horaSalida, destino, capacidadMaxima, aeropuertoPartida, null);
                aeropuertos.get(aeropuertos.indexOf(aeropuertoPartida)).registrarVueloPartida(vuelo);

                System.out.println("Vuelo de partida registrado exitosamente.");
            } else {
                System.out.println("Aeropuerto de partida no encontrado.");
            }
        } else {
            System.out.println("Ya existe un vuelo con ese numero.");
        }
    }

    private static void registrarVueloLlegada(ArrayList<Aeropuerto> aeropuertos, Scanner scanner) {
        System.out.print("Ingrese el numero de vuelo: ");
        int numeroVuelo = scanner.nextInt();
        scanner.nextLine();
    
        if (!existeNumeroVuelo(aeropuertos, numeroVuelo)) {
            System.out.print("Ingrese el nombre de la aerolinea: ");
            String aerolinea = scanner.nextLine();
            System.out.print("Ingrese la hora de llegada: ");
            String horaLlegada = scanner.nextLine();
            System.out.print("Ingrese el origen: ");
            String origen = scanner.nextLine();
            System.out.print("Ingrese la capacidad maxima: ");
            int capacidadMaxima = scanner.nextInt();
            scanner.nextLine();
    
            System.out.print("Ingrese el nombre del aeropuerto de llegada: ");
            String nombreAeropuertoLlegada = scanner.nextLine();
            Aeropuerto aeropuertoLlegada = buscarAeropuertoPorNombre(aeropuertos, nombreAeropuertoLlegada);
    
            if (aeropuertoLlegada != null) {
                Vuelo vuelo = new Vuelo(numeroVuelo, aerolinea, horaLlegada, origen, capacidadMaxima, null, aeropuertoLlegada);
                aeropuertos.get(aeropuertos.indexOf(aeropuertoLlegada)).registrarVueloLlegada(vuelo);
    
                System.out.println("Vuelo de llegada registrado con exito.");
            } else {
                System.out.println("Aeropuerto de llegada no encontrado.");
            }
        } else {
            System.out.println("Ya existe un vuelo con ese numero.");
        }
    }
    
    private static void verCantidadPasajerosEnVuelo(ArrayList<Aeropuerto> aeropuertos, Scanner scanner) {
        System.out.print("Ingrese el numero de vuelo: ");
        int numeroVuelo = scanner.nextInt();
        scanner.nextLine();
    
        Vuelo vuelo = buscarVueloPorNumero(aeropuertos, numeroVuelo);
        if (vuelo != null) {
            System.out.println("La cantidad de pasajeros en el vuelo " + numeroVuelo + " es: " + vuelo.getPasajeros().size());
        } else {
            System.out.println("No se encontro el vuelo con el numero especificado.");
        }
    }
    private static Vuelo buscarVueloPorNumero(ArrayList<Aeropuerto> aeropuertos, int numeroVuelo) {
        for (Aeropuerto aeropuerto : aeropuertos) {
            for (Vuelo vuelo : aeropuerto.getVuelosPartida()) {
                if (vuelo.getNumeroVuelo() == numeroVuelo) {
                    return vuelo;
                }
            }
            for (Vuelo vuelo : aeropuerto.getVuelosLlegada()) {
                if (vuelo.getNumeroVuelo() == numeroVuelo) {
                    return vuelo;
                }
            }
        }
        return null;
    }

    private static boolean existeNumeroVuelo(ArrayList<Aeropuerto> aeropuertos, int numeroVuelo) {
        for (Aeropuerto aeropuerto : aeropuertos) {
            for (Vuelo vuelo : aeropuerto.getVuelosPartida()) {
                if (vuelo.getNumeroVuelo() == numeroVuelo) {
                    return true;
                }
            }
            for (Vuelo vuelo : aeropuerto.getVuelosLlegada()) {
                if (vuelo.getNumeroVuelo() == numeroVuelo) {
                    return true;
                }
            }
        }
        return false;
    }

    private static Aeropuerto buscarAeropuertoPorNombre(ArrayList<Aeropuerto> aeropuertos, String nombre) {
        for (Aeropuerto aeropuerto : aeropuertos) {
            if (aeropuerto.getNombre().equalsIgnoreCase(nombre)) {
                return aeropuerto;
            }
        }
        return null;
    }
}

    
