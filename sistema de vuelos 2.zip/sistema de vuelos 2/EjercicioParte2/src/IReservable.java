interface IReservable {
    boolean reservarAsiento(int numeroAsiento);
}