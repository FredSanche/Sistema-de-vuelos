interface IPagable {
    double calcularPrecioReserva();
}